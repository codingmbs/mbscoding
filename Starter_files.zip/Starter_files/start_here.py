#Write your first line of code bellow:
print("Welcome to Python!")
# Use this link as a guide:https://www.geeksforgeeks.org/python-program-to-print-hello-world/