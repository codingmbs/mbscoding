#len()
#min() 
#max() 
#sum()

#write as a comment what each function returns
fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)

for x in "banana":
  print(x)

fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x) 
  if x == "banana":
    break
#write your final to do bellow:
  

for i in range(5):
    if i == 5:
        break
else:
    print("Loop completed successfully")  # This will be printed
