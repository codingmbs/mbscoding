def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n-1)
def is_palindrome(s): #This function checks if a given string is a palindrome (reads the same forwards as backwards).

    return s == s[::-1]

def find_max(lst):
    if len(lst) == 0:
        return None
    else:
        return max(lst)
    
#Write your own function here:




#Given a string in the format "YYYY-MM-DD", extract and print the year, month, and day separately.
date_string = "2023-09-06"
#tip: create variables for year, month and date and add the indexing to them



#Write your .format todo bellow:


