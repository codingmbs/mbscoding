# 🐍 Write answers to the 3 simple expressions as comments bellow:



# 🤖 Write 4 operations as comments bellow:



# 💀 Write your code bellow:


